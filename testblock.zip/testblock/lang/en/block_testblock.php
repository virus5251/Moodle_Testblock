<?php
/**
 *
 * @package   block_testblock
 */

$string['testblock:addinstance'] = 'Add a new test block';
$string['testblock:myaddinstance'] = 'Add a new test block to Dashboard';
$string['testblock'] = 'moodle test block';
$string['pluginname'] = 'testblock';
$string['showcourses'] = 'Show courses';
$string['showcoursesdesc'] = 'Show courses instead of users';