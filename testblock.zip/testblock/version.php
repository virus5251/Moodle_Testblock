<?php

/**
 * Version details
 *
 * @package    block_testblock
 */

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2020061500;        // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires  = 2020060900;        // Requires this Moodle version
$plugin->component = 'block_testblock';      // Full name of the plugin (used for diagnostics)
